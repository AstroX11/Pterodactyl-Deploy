const { spawnSync } = require('child_process');
const { existsSync, writeFileSync } = require('fs');
const path = require('path');

const USER_NUMBER = '';
const SUDO = '';
const BOT_NAME = '';
const OWNER_NAME = '';

const checkPnpm = spawnSync('pnpm', ['--version'], { stdio: 'ignore' });
if (checkPnpm.status !== 0) {
	console.log('pnpm not found. Installing pnpm globally...');
	const installPnpm = spawnSync('npm', ['install', '-g', 'pnpm'], {
		stdio: 'inherit',
	});
	if (installPnpm.error || installPnpm.status !== 0) {
		throw new Error(
			`Failed to install pnpm: ${
				installPnpm.error?.message || 'Unknown error'
			}`,
		);
	}
}

const repoName = 'whatsapp-bot';
const repoURL = 'https://github.com/AstroXTeam/whatsapp-bot.git';
const configPath = path.join(repoName, 'config.env');

if (!existsSync(repoName)) {
	console.log('Cloning the repository...');
	const cloneResult = spawnSync('git', ['clone', repoURL, repoName], {
		stdio: 'inherit',
	});
	if (cloneResult.error || cloneResult.status !== 0) {
		throw new Error(
			`Failed to clone the repository: ${
				cloneResult.error?.message || 'Unknown error'
			}`,
		);
	}
} else {
	console.log(`Directory "${repoName}" already exists. Skipping clone.`);
}

try {
	console.log('Writing to config.env...');
	writeFileSync(
		configPath,
		`USER_NUMBER=${USER_NUMBER}
SUDO=${SUDO ?? ''}
BOT_NAME=${BOT_NAME}
OWNER_NAME=${OWNER_NAME}
`,
	);
} catch (err) {
	throw new Error(`Failed to write to config.env: ${err.message}`);
}

console.log('Installing packages...');
const installResult = spawnSync('pnpm', ['install'], {
	cwd: repoName,
	stdio: 'inherit',
});
if (installResult.error || installResult.status !== 0) {
	throw new Error(
		`Failed to install dependencies: ${
			installResult.error?.message || 'Unknown error'
		}`,
	);
}

console.log('Starting the bot...');
const startResult = spawnSync('pnpm', ['start'], {
	cwd: repoName,
	stdio: 'inherit',
});
if (startResult.error || startResult.status !== 0) {
	throw new Error(
		`Failed to start the bot: ${startResult.error?.message || 'Unknown error'}`,
	);
}
